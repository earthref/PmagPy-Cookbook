#!/usr/bin/env python
def gimmepi():  
    """
    returns pi
    """
    return 3.141592653589793
print gimmepi()
